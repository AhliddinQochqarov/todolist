// let menu = document.querySelector('#menu');
// let li = document.createElement('li');
// li.innerHTML=`<a>Project</a>`
// // menu.replaceChild(li, menu.children[3])
// // menu.removeChild(menu.children[3]);

// let menuClone = menu.cloneNode(true);
// console.log(menuClone);
// let nav = document.querySelector('nav');
// nav.appendChild(menuClone)

// let box = document.querySelector('.box');
// box.insertAdjacentHTML('afterbegin',`<h2>Javascriot</h2>`)
// li.innerHTML=`<p>whello</p>`;
// let form = document.querySelector('form');
// let input = document.querySelector('input');
// function add(){
// console.log(input.value)
// }
// let list = document.querySelector('#language');
// function showLetter(){
//   let value = document.querySelector('#letter').value;
//   let li = document.createElement('li');
//   li.innerHTML = value[value.length - 1];
//   list.appendChild(li)
// }
let box = document.querySelector('.box');
function namec(){
  let colorName = document.querySelector('.input1').value;
  console.log(colorName)
}
function add(){
  let ol = document.querySelector('ol')
  let li = document.createElement('li')
  let colorName = document.querySelector('.input1').value;
  li.innerHTML = `${colorName}`
  let num = document.createElement('li')
  let re = document.querySelector('.input2').value;
  num.innerHTML=`${re}`;
  
  if(`${re}` <= 4){
    ol.replaceChild(li, ol.children[re])
  }
  else{
    ol.appendChild(li)
  }
}


// function insertElem(position){
//   if(position == 'beforebegin'){
//     box.insertAdjacentHTML('beforebegin',`<h2>html</h2>`)
//   }
//   else if(position == 'afterbegin'){
//     box.insertAdjacentHTML('afterbegin',`<h2>css</h2>`)
//   }
//   else if(position == 'beforeend'){
//     box.insertAdjacentHTML('beforeend',`<h2>js</h2>`)
//   }  else if(position == 'afterend'){
//     box.insertAdjacentHTML('afterend',`<h2>py</h2>`)
//   }
// }

